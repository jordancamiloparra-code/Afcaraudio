(function(){const o=document.createElement("link").relList;if(o&&o.supports&&o.supports("modulepreload"))return;for(const a of document.querySelectorAll('link[rel="modulepreload"]'))s(a);new MutationObserver(a=>{for(const e of a)if(e.type==="childList")for(const i of e.addedNodes)i.tagName==="LINK"&&i.rel==="modulepreload"&&s(i)}).observe(document,{childList:!0,subtree:!0});function n(a){const e={};return a.integrity&&(e.integrity=a.integrity),a.referrerPolicy&&(e.referrerPolicy=a.referrerPolicy),a.crossOrigin==="use-credentials"?e.credentials="include":a.crossOrigin==="anonymous"?e.credentials="omit":e.credentials="same-origin",e}function s(a){if(a.ep)return;a.ep=!0;const e=n(a);fetch(a.href,e)}})();const K="573138546529",O="af_lujos_catalog_v2",$="af_lujos_admin_session",X="adminafcaraudio",Y="Caraudio96",Z=[{id:"toyota-tundra-hilux-102",brand:"toyota",topColombia:!0,badge:"🔥 #1 Más Comprado",title:"Pantalla Android 13 QLED para Toyota Hilux / Fortuner / Prado / Tundra",specs:'Pantalla 10.2" QLED | Octa-Core | CarPlay & Android Auto Inalámbrico + Arnés OEM',reviews:52,price:"",oldPrice:"",image:"/images/products/imagen-1.webp"},{id:"vivid13-split-screen",brand:"toyota",topColombia:!0,badge:"Pantalla Dividida Waze + Música",title:'Radio Pantalla Vivid13 QLED 10.2" CarPlay & Android Auto Inalámbrico',specs:'10.2" QLED | 4GB/64GB - 8GB/128GB | Ecualizador DSP + Cámara Reversa AHD',reviews:47,price:"",oldPrice:"",image:"/images/products/prod-vivid13-tundra.jpg"},{id:"honda-accord-crv-oem",brand:"honda",topColombia:!0,badge:"Consola Original Honda",title:"Pantalla Android 13 QLED para Honda CR-V / Civic / Accord / HR-V",specs:'Pantalla 10.2" QLED | Consola a Medida + Canbus Mandos de Volante Originales',reviews:47,price:"",oldPrice:"",image:"/images/products/prod-honda-accord.jpg"},{id:"tacoma-g13-knobs",brand:"toyota",topColombia:!1,badge:"Diseño OEM con Perillas Físicas",title:"Pantalla G13 Android QLED con Perillas Físicas para Toyota Tacoma / Prado / 4Runner",specs:'10.2" QLED Android 13 | CarPlay Inalámbrico + Controles Físicos de Volumen',reviews:39,price:"",oldPrice:"",image:"/images/shorts/real-install-1.jpg"},{id:"nissan-xtrail-qashqai-kicks",brand:"nissan",topColombia:!0,badge:"🔥 Top Ventas Nissan",title:"Pantalla Android 13 QLED para Nissan X-Trail / Qashqai / Kicks / Frontier / Versa",specs:'Pantalla 10.2" QLED | Consola Negro Piano OEM + Compatible Cámara 360°',reviews:44,price:"",oldPrice:"",image:"/images/products/prod-nissan-xtrail.jpg"},{id:"renault-duster-sandero-logan",brand:"renault",topColombia:!0,badge:"🇨🇴 #1 Renault en Bogotá",title:'Kit Pantalla Android QLED 9" para Renault Duster / Sandero / Logan / Stepway / Kwid',specs:"CarPlay & Android Auto Inalámbrico | Bisel Original + Canbus Timón + Cámara AHD",reviews:94,price:"",oldPrice:"",image:"/images/products/imagen-2.webp"},{id:"mazda-2-3-cx5-cx30",brand:"mazda",topColombia:!0,badge:"🔥 Favorito Mazda Colombia",title:"Pantalla Android QLED para Mazda 2 / Mazda 3 / CX-5 / CX-30 / Mazda 5",specs:'Pantalla 9" y 10.33" QLED | Conserva Comando Joystick, Cámara y Sonido Original',reviews:64,price:"",oldPrice:"",image:"/images/products/prod-mazda.jpg"},{id:"chevrolet-onix-tracker-silverado",brand:"chevrolet",topColombia:!0,badge:"🇨🇴 #1 Chevrolet en Local 116",title:"Kit Pantalla Android QLED para Chevrolet Onix / Tracker / Spark GT / Sail / Captiva",specs:"Pacha Original GM Plug & Play | Canbus Integrado + Cámara Reversa AHD 170°",reviews:81,price:"",oldPrice:"",image:"/images/products/prod-chevrolet-silverado.jpg"},{id:"toyota-corolla-oem-knob",brand:"toyota",topColombia:!0,badge:"Encaje Exacto Corolla",title:'Pantalla Android 11.6" QLED para Toyota Corolla con Consola Asimétrica OEM',specs:'Pantalla 11.6" QLED | CarPlay Inalámbrico + Arnés Plug & Play Sin Cortar Cables',reviews:36,price:"",oldPrice:"",image:"/images/products/prod-corolla.jpg"},{id:"kia-picanto-sportage-hyundai",brand:"kia",topColombia:!0,badge:"🔥 Top Kia / Hyundai",title:'Pantalla Android QLED 9" para Kia Picanto / Rio / Sportage & Hyundai Tucson / Accent',specs:"Consola Original a Medida | CarPlay & Android Auto + Cámara Visión Nocturna",reviews:58,price:"",oldPrice:"",image:"/images/products/prod-4runner.jpg"},{id:"jeep-wrangler-renegade-compass",brand:"jeep",topColombia:!1,badge:"Especial 4x4 Jeep",title:"Pantalla Android QLED para Jeep Renegade / Compass / Wrangler JL / Cherokee",specs:"Canbus Off-Road Activo | Mandos de Timón + CarPlay Inalámbrico + Cámara HD",reviews:29,price:"",oldPrice:"",image:"/images/shorts/real-install-3.jpg"},{id:"ford-ranger-escape-ecosport",brand:"ford",topColombia:!0,badge:"Compatible SYNC Original",title:"Pantalla Android QLED para Ford Escape / Ranger / EcoSport / Fiesta / Explorer",specs:"Conserva Controles de Volante y Sensores | CarPlay Inalámbrico + GPS Waze",reviews:34,price:"",oldPrice:"",image:"/images/products/prod-vivid13-tundra.jpg"},{id:"vw-gol-jetta-amarok-tcross",brand:"volkswagen",topColombia:!0,badge:"Canbus Original VW",title:"Pantalla Android QLED para Volkswagen Gol / Voyage / Jetta / Amarok / T-Cross",specs:'Pantalla 9" QLED | Arnés Quadlock VW + Sensores Ópticos + Cámara Reversa AHD',reviews:31,price:"",oldPrice:"",image:"/images/products/imagen-1.webp"}],F={all:"Todas las Marcas",colombia:"Top Más Comprados en Colombia",toyota:"Toyota",honda:"Honda",nissan:"Nissan",chevrolet:"Chevrolet",jeep:"Jeep",renault:"Renault",mazda:"Mazda",kia:"Kia / Hyundai",ford:"Ford",volkswagen:"Volkswagen"};let P="all";function w(){try{const t=localStorage.getItem(O);if(t){const o=JSON.parse(t);if(Array.isArray(o)&&o.length>0)return o}}catch(t){console.warn("Error leyendo catálogo local:",t)}return[...Z]}function N(t){try{localStorage.setItem(O,JSON.stringify(t))}catch{alert("No se pudo guardar la imagen porque es demasiado pesada. Intenta con una foto más liviana o URL.")}}function U(t){return`https://wa.me/${K}?text=${encodeURIComponent(t)}`}function V(t,o={}){window.dataLayer=window.dataLayer||[],window.dataLayer.push({event:t,store_location:"CC Bucanero Local 116 - Cra 38 # 6-28 Bogota",...o})}function p(t=""){return String(t).replace(/&/g,"&amp;").replace(/</g,"&lt;").replace(/>/g,"&gt;").replace(/"/g,"&quot;").replace(/'/g,"&#39;")}function A(t=P){P=t;const o=document.getElementById("products-carousel-track"),n=document.getElementById("active-filter-label");if(!o)return;const s=w();let a=s;t==="colombia"?a=s.filter(e=>e.topColombia):t!=="all"&&(a=s.filter(e=>e.brand===t)),a.length===0&&(a=s),n&&(n.textContent=t==="all"?"Las pantallas Android QLED y consolas originales más instaladas en nuestro Local 116. Haz clic en cotizar o comprar para agendar por WhatsApp.":`Mostrando equipos compatibles con ${F[t]||t} disponibles hoy en el Local 116 (${a.length} opciones):`),o.innerHTML=a.map((e,i)=>{const l=!!(e.price&&String(e.price).trim().length>0),m=!!(e.oldPrice&&String(e.oldPrice).trim().length>0),d=l?`Hola AF Car Audio, quiero comprar/cotizar: ${e.title} (${e.price}). ¿Tienen disponibilidad para instalar hoy en el Local 116 (C.C. Bucanero)?`:`Hola AF Car Audio, quiero cotizar el precio e instalación de: ${e.title}. ¿Tienen disponibilidad hoy en el Local 116 (C.C. Bucanero)?`,b=U(d),v=l?`
          <div class="flex items-baseline gap-2 mb-3">
            <span class="text-xs text-zinc-500">Desde</span>
            <span class="text-xl font-black text-zinc-950">${p(e.price)}</span>
            ${m?`<span class="text-xs text-zinc-400 line-through">${p(e.oldPrice)}</span>`:""}
          </div>
        `:`
          <div class="flex items-center justify-between mb-3 text-xs font-semibold text-emerald-700 bg-emerald-50 border border-emerald-200/80 rounded-lg px-2.5 py-1.5">
            <span>✓ Disponible en Local 116</span>
            <span>Instalación Hoy</span>
          </div>
        `;return`
        <article
          role="group"
          aria-roledescription="slide"
          aria-label="${i+1} de ${a.length}: ${p(e.title)}"
          class="w-[270px] sm:w-[295px] shrink-0 rounded-2xl bg-white border border-zinc-200/90 p-5 shadow-sm hover:shadow-xl transition flex flex-col justify-between"
        >
          <div>
            <!-- Foto Real del Producto sobre fondo blanco limpio -->
            <div class="relative aspect-square w-full rounded-xl bg-white overflow-hidden mb-4 flex items-center justify-center p-2">
              <span class="absolute top-2 left-2 z-10 rounded-full bg-zinc-900/90 text-white px-2.5 py-1 text-[11px] font-bold">
                ${p(e.badge||"🔥 Destacado")}
              </span>
              <img
                src="${p(e.image)}"
                alt="${p(e.title)}"
                width="400"
                height="400"
                loading="lazy"
                decoding="async"
                class="w-full h-full object-contain transition duration-300 hover:scale-105"
              />
            </div>

            <!-- Título y Especificaciones 100% en Español -->
            <h3 class="text-sm sm:text-base font-extrabold text-zinc-900 line-clamp-2 leading-snug">
              ${p(e.title)}
            </h3>
            <p class="text-xs text-zinc-500 mt-1.5 line-clamp-2 leading-relaxed">
              ${p(e.specs)}
            </p>

            <!-- Calificación en Español -->
            <div class="flex items-center gap-1.5 mt-3">
              <div class="flex text-amber-400 text-sm tracking-tight" aria-label="5 de 5 estrellas">
                ★★★★★
              </div>
              <span class="text-xs text-zinc-500 font-medium">${Number(e.reviews)||45} opiniones</span>
            </div>
          </div>

          <div class="mt-4 pt-3 border-t border-zinc-100">
            ${v}

            <!-- Botón de Compra / Cotización que dirige directo a WhatsApp -->
            <a
              href="${b}"
              target="_blank"
              rel="noopener noreferrer"
              data-gtm-event="whatsapp_click"
              data-product-id="${p(e.id)}"
              class="w-full inline-flex items-center justify-center gap-2 rounded-xl bg-[#0B4F8A] hover:bg-[#083B66] text-white font-extrabold text-xs sm:text-sm py-3 px-4 shadow-sm transition"
            >
              <span>${l?"Comprar por WhatsApp":"Cotizar / Comprar por WhatsApp"}</span>
            </a>
          </div>
        </article>
      `}).join("")}function ee(){A("all");const t=document.getElementById("products-carousel-track"),o=document.getElementById("carousel-prev"),n=document.getElementById("carousel-next");o&&t&&o.addEventListener("click",()=>{t.scrollBy({left:-320,behavior:"smooth"})}),n&&t&&n.addEventListener("click",()=>{t.scrollBy({left:320,behavior:"smooth"})});const s=document.querySelectorAll("[data-filter-tab]"),a=document.querySelectorAll("[data-brand-card]"),e=document.getElementById("reset-vehicle-filter");function i(l,m=!1){if(s.forEach(d=>{const b=d.getAttribute("data-filter-tab")===l;d.className=b?"product-filter-tab rounded-full bg-zinc-900 text-white px-4 py-2 text-xs font-bold transition cursor-pointer":"product-filter-tab rounded-full bg-white border border-zinc-300 text-zinc-700 hover:bg-zinc-100 px-4 py-2 text-xs font-bold transition cursor-pointer"}),a.forEach(d=>{const b=d.getAttribute("data-brand-card")===l;d.classList.toggle("ring-4",b),d.classList.toggle("ring-[#E11D48]",b)}),A(l),m){const d=document.getElementById("mas-populares");d&&d.scrollIntoView({behavior:"smooth",block:"start"})}}s.forEach(l=>{l.addEventListener("click",()=>{const m=l.getAttribute("data-filter-tab")||"all";i(m,!1)})}),a.forEach(l=>{l.addEventListener("click",()=>{const m=l.getAttribute("data-brand-card")||"all",d=document.getElementById("quick-car-model");d&&!d.value.trim()&&(d.value=F[m]||m),i(m,!0)})}),e&&e.addEventListener("click",()=>{i("all",!0)})}function te(){const t=document.getElementById("quick-quote-form"),o=document.getElementById("quick-category"),n=document.getElementById("quick-car-model");if(!t||!o||!n)return;const s=CSS.supports("selector(:user-invalid)"),a=new WeakMap;function e(i){!s&&a.get(i)&&(i.classList.toggle("user-invalid-fallback",!i.validity.valid),i.classList.toggle("user-valid-fallback",i.validity.valid)),i.validity.valid?i.removeAttribute("aria-invalid"):a.get(i)&&i.setAttribute("aria-invalid","true")}n.addEventListener("blur",()=>{a.set(n,!0),e(n)}),n.addEventListener("input",()=>{a.get(n)&&e(n)}),t.addEventListener("submit",i=>{if(i.preventDefault(),a.set(n,!0),e(n),!t.checkValidity()){n.focus();return}const l=o.value.trim(),m=n.value.trim(),d=`Hola AF Car Audio, cotizo ${l} para mi ${m}. ¿Tienen disponibilidad para instalar hoy en el Local 116?`,b=U(d);V("whatsapp_click",{lead_source:"hero_quick_quote_widget",category:l,car_model:m}),window.open(b,"_blank","noopener,noreferrer")})}function ae(){const t=document.getElementById("admin-login-dialog"),o=document.getElementById("admin-dashboard-dialog"),n=document.getElementById("admin-login-form"),s=document.getElementById("admin-login-error"),a=document.getElementById("admin-username"),e=document.getElementById("admin-password"),i=document.getElementById("toggle-admin-password"),l=document.getElementById("close-admin-login"),m=document.getElementById("close-admin-dashboard"),d=document.getElementById("admin-logout-btn"),b=document.getElementById("admin-reset-defaults"),v=document.getElementById("admin-product-form"),B=document.getElementById("admin-prod-id"),k=document.getElementById("admin-prod-title"),_=document.getElementById("admin-prod-brand"),D=document.getElementById("admin-prod-badge"),R=document.getElementById("admin-prod-specs"),S=document.getElementById("admin-prod-price"),j=document.getElementById("admin-prod-old-price"),H=document.getElementById("admin-prod-image-file"),E=document.getElementById("admin-prod-image-url"),z=document.getElementById("admin-prod-top-colombia"),L=document.getElementById("admin-form-heading"),h=document.getElementById("admin-cancel-edit-btn"),I=document.getElementById("admin-products-list"),Q=document.getElementById("admin-products-count");if(!t||!o)return;function G(){const u=new URLSearchParams(window.location.search),r=window.location.hash.toLowerCase();return u.has("admin")||r==="#admin"||r==="#panel-admin"||r==="#administracion"}function W(){return sessionStorage.getItem($)==="true"}function T(){(window.location.hash||window.location.search.includes("admin"))&&window.history.replaceState({},document.title,window.location.pathname)}function C(){if(!I)return;const u=w();Q&&(Q.textContent=String(u.length)),I.innerHTML=u.map(r=>`
        <div class="flex flex-col sm:flex-row sm:items-center justify-between gap-3 rounded-xl bg-[#09090B] border border-zinc-800 p-3.5">
          <div class="flex items-center gap-3 min-w-0">
            <img
              src="${p(r.image)}"
              alt="${p(r.title)}"
              width="56"
              height="56"
              class="h-14 w-14 rounded-lg bg-white object-contain p-1 shrink-0"
            />
            <div class="min-w-0">
              <span class="inline-block text-[10px] font-bold uppercase tracking-wider text-[#E11D48]">
                ${p(F[r.brand]||r.brand)}
              </span>
              <h4 class="text-xs sm:text-sm font-bold text-white truncate">${p(r.title)}</h4>
              <p class="text-xs text-zinc-400">
                Precio actual:
                <strong class="${r.price?"text-emerald-400":"text-amber-400"}">
                  ${r.price?p(r.price):"Sin precio (Solo cotizar)"}
                </strong>
              </p>
            </div>
          </div>

          <div class="flex items-center gap-2 shrink-0">
            <button
              type="button"
              data-admin-edit="${p(r.id)}"
              class="rounded-lg bg-zinc-800 hover:bg-zinc-700 text-white px-3 py-1.5 text-xs font-bold transition cursor-pointer"
            >
              ✏️ Editar / Poner Precio
            </button>
            <button
              type="button"
              data-admin-delete="${p(r.id)}"
              class="rounded-lg bg-rose-950/60 hover:bg-rose-900 border border-rose-800/60 text-rose-200 px-2.5 py-1.5 text-xs font-bold transition cursor-pointer"
              aria-label="Eliminar producto"
            >
              🗑
            </button>
          </div>
        </div>
      `).join("")}function M(){v&&(v.reset(),B.value="",D.value="🔥 Destacado Local 116",E.value="/images/products/imagen-1.webp",z.checked=!0,L&&(L.textContent="➕ Agregar Nuevo Producto al Catálogo"),h&&h.classList.add("hidden"))}function q(){G()&&(W()?(t.open&&t.close(),C(),o.open||o.showModal()):(o.open&&o.close(),s&&s.classList.add("hidden"),t.open||t.showModal()))}i&&e&&i.addEventListener("click",()=>{const u=e.type==="password";e.type=u?"text":"password",i.textContent=u?"Ocultar contraseña":"Mostrar contraseña"}),l&&l.addEventListener("click",()=>{t.close(),T()}),m&&m.addEventListener("click",()=>{o.close(),T()}),d&&d.addEventListener("click",()=>{sessionStorage.removeItem($),o.close(),T()}),n&&n.addEventListener("submit",u=>{u.preventDefault();const r=((a==null?void 0:a.value)||"").trim(),f=(e==null?void 0:e.value)||"";r===X&&f===Y?(sessionStorage.setItem($,"true"),s&&s.classList.add("hidden"),n.reset(),t.close(),C(),o.showModal()):s&&s.classList.remove("hidden")}),H&&E&&H.addEventListener("change",u=>{var g;const r=(g=u.target.files)==null?void 0:g[0];if(!r)return;const f=new FileReader;f.onload=()=>{typeof f.result=="string"&&(E.value=f.result)},f.readAsDataURL(r)}),v&&v.addEventListener("submit",u=>{u.preventDefault();const r=k.value.trim(),f=R.value.trim();if(!r||!f){k.focus();return}const g=w(),y=B.value.trim(),c={id:y||`prod-${Date.now()}`,brand:_.value||"toyota",topColombia:!!z.checked,badge:D.value.trim()||"🔥 Destacado Local 116",title:r,specs:f,reviews:48,price:S.value.trim(),oldPrice:j.value.trim(),image:E.value.trim()||"/images/products/imagen-1.webp"};if(y){const x=g.findIndex(J=>J.id===y);x!==-1?(c.reviews=g[x].reviews||48,g[x]=c):g.unshift(c)}else g.unshift(c);N(g),A(P),C(),M()}),h&&h.addEventListener("click",()=>{M()}),I&&I.addEventListener("click",u=>{const r=u.target.closest("[data-admin-edit]"),f=u.target.closest("[data-admin-delete]");if(r){const g=r.getAttribute("data-admin-edit"),c=w().find(x=>x.id===g);if(!c)return;B.value=c.id,k.value=c.title||"",_.value=c.brand||"toyota",D.value=c.badge||"",R.value=c.specs||"",S.value=c.price||"",j.value=c.oldPrice||"",E.value=c.image||"/images/products/imagen-1.webp",z.checked=!!c.topColombia,L&&(L.textContent=`✏️ Editando: ${c.title.slice(0,32)}...`),h&&h.classList.remove("hidden"),S.focus()}if(f){const g=f.getAttribute("data-admin-delete"),y=w().filter(c=>c.id!==g);N(y),A(P),C()}}),b&&b.addEventListener("click",()=>{localStorage.removeItem(O),A(P),C(),M()}),window.addEventListener("hashchange",q),q()}function oe(){document.addEventListener("click",t=>{const o=t.target.closest("[data-gtm-event]");if(!o)return;const n=o.getAttribute("data-gtm-event"),s=o.getAttribute("data-product-id")||void 0;V(n,{element_text:(o.textContent||"").trim().slice(0,60),product_id:s})})}document.addEventListener("DOMContentLoaded",()=>{ee(),te(),ae(),oe()});
